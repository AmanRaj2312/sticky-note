const data = [
  {
    "id": "3effea2c-fc90-98e0-51d0-22c32efb2177",
    "text": "Hey I am Ajain... ",
    "title": "Hello",
    "grid": {
      "i": "3effea2c-fc90-98e0-51d0-22c32efb2177",
      "x": 0,
      "y": null,
      "w": 2,
      "h" : 2,
      "isDraggable": false
    },
    "contentEditable": true,
    "timeStamp": "13 Feb 2017 2:53 PM"
  },
  {
    "id": "3effea2c-fc90-98e0-51d0-22c32efb2178",
    "text": "If you liked stickies... contribute by liking it... ",
    "title": "Contribute",
    "grid": {
      "i": "3effea2c-fc90-98e0-51d0-22c32efb2178",
      "x": 4,
      "y": 0,
      "w": 4,
      "h" : 4,
      "isDraggable": false
    },
    "contentEditable": true,
    "timeStamp": "13 Feb 2017 2:53 PM"
  }
]

export default data;
