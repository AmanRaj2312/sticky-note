import { default as Stickies } from './components/Stickies';

export {
  Stickies
};

export default Stickies;
